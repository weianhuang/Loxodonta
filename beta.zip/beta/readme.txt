This is our beta release. Explore the rooms to find the key and then the victory room. Keep in mind, you may have to kill the key enemy to steal their key! Collect peanuts to replenish your health and stay alive as long as you can. Enjoy our five levels displaying different levels of difficulty. 

Controls:
Move - Arrow Keys or Left Stick on Xbox Controller
Dash - Z or RB
Melee - X or LB
Restart - R or Back 